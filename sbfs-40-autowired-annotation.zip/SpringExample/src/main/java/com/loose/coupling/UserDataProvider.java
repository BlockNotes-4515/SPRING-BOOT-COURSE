package com.loose.coupling;

public interface UserDataProvider {
    String getUserDetails();
}
